const { response } = require("express");

// middleware/errorHandler.js
const errorHandler = (error, request, response, next) => {
    if (error.name === 'ValidationError') {
      return response.status(400).json({ message: error.message });
    }
    
    console.error(error.stack);
    res.status(500).json({ message: 'Something went wrong!' });
  };
  
  module.exports = errorHandler;
  