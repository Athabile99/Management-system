/* global use, db */
// MongoDB Playground
// To disable this template go to Settings | MongoDB | Use Default Template For Playground.
// Make sure you are connected to enable completions and to be able to run a playground.
// Use Ctrl+Space inside a snippet or a string literal to trigger completions.
// The result of the last command run in a playground is shown on the results panel.
// By default the first 20 documents will be returned with a cursor.
// Use 'console.log()' to print to the debug output.
// For more documentation on playgrounds please refer to
// https://www.mongodb.com/docs/mongodb-vscode/playgrounds/

// Select the database to use.
use('mytaskdatabase');


// ------------------- USERS----------------
// Create a new user

db.getCollection('Users').insertOne([{"name":"My task","description" : "Description of task", "date_time" : "2016-05-25 14:25:00"}]
);

//update user
db.Users.updateOne(
    { "username": "jsmith" },
    { $set: { "first_name": "Jonathan" } }
);
//list all users
db.Users.find().pretty();

//Delete user
db.Users.deleteOne(
    { "username": "jsmith" }
);
// ------------TASKS-------
//create a tasks
db.Tasks.insertOne({
    "name": "My task",
    "description": "Description of task",
    "date_time": ISODate("2016-05-25T14:25:00Z")
});

//update tasks
db.Tasks.updateOne(
    { "name": "My task" },
    { $set: { "description": "Updated description of the task" } }
);

//show tasks

//delete tasks
db.Tasks.deleteOne(
    { "name": "My task" }
);



