const express = require('express');
const controller = express.Router();
const User = require('../model/userModel');
//database for users 
let users =[];

//get infor for all users
controller.get('/',(request,response)=>{
    response.json(users);
});

//Get a single use by unique ID
controller.get('/:id',(request, response)=>{
    const user = users.find(uniq=>uniq.id==parseInt(request.params.id));
    if(!user) return response.statusCode(404).send('user not found in our system');
    response.json(user);
});

//create a new user
controller.post('/',(request,response)=>{
    const{ username,first_name, last_name,email, cellphone_number}= request.body;
    const newUser = {
        ID:users.length +1,
        username, 
        first_name, 
        last_name,
        email, 
        cellphone_number,
        tasksAssigned:[]

    }
    users.push(newUser);
    response.statusCode(201).json(newUser);
});

//update user

controller.put('/',(request,response)=>{
const user = users.find(uniq=>uniq.id===parseInt(request.params.id));
if(!user) return response.statusCode(404).send('User not found in our system');

const{ username,first_name, last_name,email, cellphone_number} = request.body;
if(username) user.username =username;
if(first_name) user.first_name =first_name;
if(last_name) user.last_name =last_name;
if(email) user.email =email;
if(cellphone_number) user.cellphone_number =cellphone_number;
});

//Delete user 
controller.delete('/:id',(request,response)=>{
    users = users.filter(uniq=>uniq.id !==parseInt(request.params.id));
    response.statusCode(204).send('User successfully deleted');
});

module.exports = {controller,users};