const express = require('express');
const controller = express.Router();

// Database for users and tasks (imported from userController)
const users = require('./userController').users;

// Get all tasks for a specified user
controller.get('/:user_id/tasks', (request, response) => {
    const user = users.find(uniq => uniq.id === parseInt(request.params.user_id));
    if (!user) return response.status(404).send('User not found in our system');
    
    response.json(user.tasks);
});

// Get a specific task for a user
controller.get('/:user_id/tasks/:task_id', (request, response) => {
    const user = users.find(uniq => uniq.id === parseInt(request.params.user_id));
    if (!user) return response.status(404).send('User not found in our system');
    
    const task = user.tasks.find(tas => tas.id === parseInt(request.params.task_id));
    if (!task) return response.status(404).send('Task not found in our system');

    response.json(task);
});

// Create a new task for a user
controller.post('/:user_id/tasks', (request, response) => {
    const user = users.find(uniq => uniq.id === parseInt(request.params.user_id));
    if (!user) return response.status(404).send('User not found in our system');

    const { taskName, description, date_time } = request.body;

    const newTask = {
        id: user.tasks.length + 1,
        taskName,
        description,
        date_time
    };

    user.tasks.push(newTask);
    response.status(201).json(newTask);
});

// Update an existing task for a user
controller.put('/:user_id/tasks/:task_id', (request, response) => {
    const user = users.find(uniq => uniq.id === parseInt(request.params.user_id));
    if (!user) return response.status(404).send('User not found in our system');
    
    const task = user.tasks.find(tas => tas.id === parseInt(request.params.task_id));
    if (!task) return response.status(404).send('Task not found in our system');

    const { taskName, description, date_time } = request.body;

    if (taskName) task.taskName = taskName;
    if (description) task.description = description;
    if (date_time) task.date_time = date_time;

    response.json(task);
});

// Delete a task for a user
controller.delete('/:user_id/tasks/:task_id', (request, response) => {
    const user = users.find(uniq => uniq.id === parseInt(request.params.user_id));
    if (!user) return response.status(404).send('User not found in our system');
    
    const taskIndex = user.tasks.findIndex(tas => tas.id === parseInt(request.params.task_id));
    if (taskIndex === -1) return response.status(404).send('Task not found in our system');

    user.tasks.splice(taskIndex, 1);
    response.send('Task successfully deleted');
});

module.exports = controller;
