const express = require("express");
const bodyParser = require("body-parser");
const logger = require("logger");
const mongoose = require("mongoose");
const dbConfig = require("./config/db.config.js");

const app = express();

app.use(logger());
app.use(bodyParser.json());

// Connect to MongoDB
mongoose.connect(dbConfig.url, {
  useNewUrlParser: true,
  useUnifiedTopology: true
}).then(() => {
  console.log("Connected to the database!");
}).catch(err => {
  console.log("Cannot connect to the database!", err);
  process.exit();
});

// Import routes
require("./controller/userController.controller")(app);
require("./controller/taskController.controller")(app);

// Set port and start the server
const PORT = process.env.PORT || 8080;
app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}.`);
});
