// this is for app.js
const express = require('express');
const bodyParser = require('body-parser');
const config = require('./config/config');
const logger = require('./middleware/logger');
const errorHandler = require('./middleware/errorHandler');

//import controllers
const userController = require('./controller/userController');
const taskController = require('./controller/taskController');
const errorHandler = require('./middleware/errorHandler');

const app = express();

//Middleware 
app.use(bodyParser.json());
app.use(logger);

//connect to MangoDB
mongoose.connect('mongodb://localhost:27017/mytaskdatabase', {
    useNewUrlParser: true,
    useUnifiedTopology: true,
})
    .then(() => console.log('Connected to MongoDB'))
    .catch(err => console.error('Error connecting to MongoDB:', err));

//Controller as routes
app.use('/api/controller/taskController.js');
app.use('/api/controller/userController.js');

//error handling
app.use(errorHandler);

//start server
app.listen(config.port, () => {
    console.log(`server is running on port ${config.port}`);

});


