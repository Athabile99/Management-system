const { MongoClient } = require('mongodb');
const cron = require('node-cron');

// MongoDB connection URI
const uri = 'mongodb://localhost:27017';
const dbName = 'mytaskdatabase';

// Create a new MongoClient
const client = new MongoClient(uri, { useUnifiedTopology: true });

async function checkTasks() {
  try {
    // Connect to MongoDB
    await client.connect();
    console.log('Connected to MongoDB');

    const db = client.db(dbName);
    const tasksCollection = db.collection('Tasks');

    // Get current date and time
    const now = new Date();

    // Find tasks that are pending and whose next_execute_date_time has passed
    const pendingTasks = await tasksCollection.find({
      status: 'pending',
      next_execute_date_time: { $lte: now }
    }).toArray();

    if (pendingTasks.length > 0) {
      console.log('Pending tasks to be updated:');
      console.log(pendingTasks);

      // Update the status of pending tasks to "done"
      await tasksCollection.updateMany(
        { status: 'pending', next_execute_date_time: { $lte: now } },
        { $set: { status: 'done' } }
      );
      console.log('Updated pending tasks to done');
    } else {
      console.log('No pending tasks to update');
    }
  } catch (err) {
    console.error('Error:', err);
  } finally {
    // Close the MongoDB connection
    await client.close();
    console.log('MongoDB connection closed');
  }
}

// Schedule the job to run every minute
cron.schedule('* * * * *', checkTasks);
