// Fetch and display all users
function fetchUsers() {
    fetch('/api/users')
      .then(response => response.json())
      .then(users => {
        const userList = document.getElementById('user-list');
        userList.innerHTML = '';
        users.forEach(user => {
          const userDiv = document.createElement('div');
          userDiv.innerHTML = `<strong>${user.id}:</strong> ${user.username} (${user.first_name} ${user.last_name}) <button onclick="deleteUser(${user.id})">Delete</button>`;
          userList.appendChild(userDiv);
        });
      })
      .catch(error => console.error('Error fetching users:', error));
  }
  
  // Create a new user
  document.getElementById('create-user-form').addEventListener('submit', function (event) {
    event.preventDefault();
  
    const username = document.getElementById('username').value;
    const first_name = document.getElementById('first_name').value;
    const last_name = document.getElementById('last_name').value;
    const email = document.getElementById('email').value;
    const cellphone_number = document.getElementById('cellphone_number').value;
  
    fetch('/api/users', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({ username, first_name, last_name, email, cellphone_number })
    })
      .then(response => response.json())
      .then(data => {
        console.log('User created:', data);
        fetchUsers();
      })
      .catch(error => console.error('Error creating user:', error));
  });
  
  // Delete a user
  function deleteUser(id) {
    fetch(`/api/users/${id}`, { method: 'DELETE' })
      .then(() => {
        console.log(`User ${id} deleted`);
        fetchUsers();
      })
      .catch(error => console.error('Error deleting user:', error));
  }
  
  // Create a task for a user
  document.getElementById('create-task-form').addEventListener('submit', function (event) {
    event.preventDefault();
  
    const userId = document.getElementById('user_id').value;
    const taskName = document.getElementById('task_name').value;
    const description = document.getElementById('description').value;
    const date_time = document.getElementById('date_time').value;
  
    fetch(`/api/users/${userId}/tasks`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({ taskName, description, date_time })
    })
      .then(response => response.json())
      .then(data => {
        console.log('Task created:', data);
        fetchTasks(userId);
      })
      .catch(error => console.error('Error creating task:', error));
  });
  
  // Fetch tasks for a user
  function fetchTasks(userId) {
    fetch(`/api/users/${userId}/tasks`)
      .then(response => response.json())
      .then(tasks => {
        const taskList = document.getElementById('task-list');
        taskList.innerHTML = '';
        tasks.forEach(task => {
          const taskDiv = document.createElement('div');
          taskDiv.innerHTML = `<strong>${task.id}:</strong> ${task.taskName} - ${task.description} <button onclick="deleteTask(${userId}, ${task.id})">Delete</button>`;
          taskList.appendChild(taskDiv);
        });
      })
      .catch(error => console.error('Error fetching tasks:', error));
  }
  
  // Delete a task
  function deleteTask(userId, taskId) {
    fetch(`/api/users/${userId}/tasks/${taskId}`, { method: 'DELETE' })
      .then(() => {
        console.log(`Task ${taskId} deleted`);
        fetchTasks(userId);
      })
      .catch(error => console.error('Error deleting task:', error));
  }
  
  // Initial fetch
  fetchUsers();
  